import React from "react";

class Dashboard extends React.Component {
    render() {
        return (
            <div className="Dashboard">
                <h1>Dashboard</h1>
            </div>

        );
    }
}

export default Dashboard;