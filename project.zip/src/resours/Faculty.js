import React from "react";


class Faculty extends React.Component {
    render() {
        return (
                <div className="Faculty">     
                    <h1>Faculty</h1>
                </div>
        );
    }
}

export default Faculty;
























































