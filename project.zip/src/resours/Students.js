import React from "react";
import Data from "./Data";

class Students extends React.Component {

    render(){
        return (
            <div className="table">
                <h2> Data Students </h2>
                <div className='userListTitle'>
                    <ul>
                        <li>id</li>
                        <li>name</li>
                        <li>position</li>
                        <li>office</li>
                        <li>age</li>
                        <li>date</li>
                        <li>salary</li>
                    </ul>
                </div>

                {Data.map((item, i) => (
                    <div className='userList'>
                        <ul>
                            <li key={i}><input type="text" value={item.id}/></li>
                            <li><input type="text" value={item.name}/></li>
                            <li><input type="text" value={item.position}/></li>
                            <li><input type="text" value={item.office}/></li>
                            <li><input type="text" value={item.age}/></li>
                            <li><input type="text" value={item.date}/></li>
                            <li><input type="text" value={item.salary}/></li>
                            <li> {item.button} </li>
                        </ul>
                    </div>))
                }
            </div>
        );
    }
}

export default Students;


