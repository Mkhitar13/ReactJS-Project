import React from "react";

class Group extends React.Component {
    render() {
        return (
                <div className="Group">
                    <h1>Group</h1>
                </div>
        );
    }
}

export default Group;