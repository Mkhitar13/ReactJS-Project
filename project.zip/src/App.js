import React from "react";
import './App.css';
import Home from "./resours/Home";

class App extends React.Component {
    render() {
        return (
            <div>
                <Home />
            </div>
        );
    }
}

export default App;








































